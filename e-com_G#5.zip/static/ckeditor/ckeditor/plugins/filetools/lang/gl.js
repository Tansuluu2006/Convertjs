﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","gl",{loadError:"Produciuse un erro durante a lectura do ficheiro.",networkError:"Produciuse un erro na rede durante o envío do ficheiro.",httpError404:"Produciuse un erro HTTP durante o envío do ficheiro (404: Ficheiro non atopado).",httpError403:"Produciuse un erro HTTP durante o envío do ficheiro (403: Acceso denegado).",httpError:"Produciuse un erro HTTP durante o envío do ficheiro (erro de estado: %1).",noUrlError:"Non foi definido o URL para o envío.",responseError:"Resposta incorrecta do servidor."});