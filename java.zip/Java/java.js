console.log(1 < 2 && 1 > 2);
console.log(1 < 2 || 1 > 2)



// let num1 = prompt('num1');
// let num2 = prompt('num2');
//
// let num3 = Number(num1);
// let num4 = Number(num2);

// if (num3 > num4){
//     console.log('Первое число больше второй');
//     document.write('<h1>Первое число больше второй</h1>');
//     let num5 = prompt('Пщставьте оценку');
//     console.log(num5);
// } else if(num3 === num4){
//     console.log('Числа между собой равны');
//     document.write('<h1>Числа между сбой равны</h1>');
// } else if(num4 > num3){
//     console.log('Второе число больше первой');
//     document.write('<h1>Второе число больше первой</h1>');
// } else {
//     console.log('Введите только числа');
//     document.write('<h1>Ведите только числа</h1>');
// }

// {num3 > num4
//     ? document.write('<h1>Первое число больше второй</h1>')
//     : num4 > num3
//         ? document.write('<h1>Второе число больше ппервой</h1>')
//         : num3 === num4
//             ? document.write('<h1>Числа между собой равны</h1>')
//             : document.write('<h1>Введите только числа</h1>')
// }

















// let prom = prompt('Введите элемент');
//
// let arr = ['BMW', 'Mers', 'Audi', 'Honda'];
//
// arr.push(prom);
//
// console.log(prom);
// console.log(arr);
//
// document.write(arr);