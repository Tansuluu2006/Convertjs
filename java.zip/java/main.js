document.querySelector('button').addEventListener('click', ()=>alert('Ваалайкум ассалом!'))

var a = 15;

let b = 30;

const c = 20;

console.log(a)
console.log(b)
console.log(c)








